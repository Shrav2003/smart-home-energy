import React from 'react';
import EnergyChart from './components/EnergyChart';
import Budget from './components/Budget';

function App() {
  return (
    <div className="App">
      <h1>Smart Home Energy Dashboard</h1>
      <EnergyChart />
      <Budget />
    </div>
  );
}

export default App;
