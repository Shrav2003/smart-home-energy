import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import axios from 'axios';

const EnergyChart = () => {
  const [chartData, setChartData] = useState({ datasets:});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8080/energy');
        const energyData = response.data;

        const labels = energyData.map((item) => item.timestamp);
        const consumption = energyData.map((item) => item.consumption);

        setChartData({
          labels: labels,
          datasets: [
            {
              label: 'Energy Consumption',
              data: consumption,
              fill: false,
              borderColor: 'rgb(75, 192, 192)',
              tension: 0.1
            }
          ]
        });
      } catch (error) {
        console.error('Error fetching data:', error);
        setError(error); // Set the error state to display an error message
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  },);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  return (
    <div style={{ width: '80%', margin: 'auto' }}>
      <Line data={chartData} />
    </div>
  );
};

export default EnergyChart;
