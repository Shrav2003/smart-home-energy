import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Budget = () => {
  const [budget, setBudget] = useState(0);
  const [newBudget, setNewBudget] = useState(0);

  useEffect(() => {
    const fetchBudget = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8080/budget');
        setBudget(response.data.budget);
      } catch (error) {
        console.error('Error fetching budget:', error);
        // Handle error, e.g., display an error message
      }
    };

    fetchBudget();
  },);

  const handleBudgetChange = async () => {
    try {
      await axios.post('http://127.0.0.1:8080/budget', { budget: newBudget });
      setBudget(newBudget);
    } catch (error) {
      console.error('Error updating budget:', error);
      // Handle error, e.g., display an error message
    }
  };

  return (
    <div>
      <p>Current Budget: {budget}</p>
      <input
        type="number"
        value={newBudget}
        onChange={(e) => setNewBudget(parseFloat(e.target.value))}
      />
      <button onClick={handleBudgetChange}>Update Budget</button>
    </div>
  );
};

export default Budget;
