# backend/main.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from database import create_connection
import datetime
import random

app = FastAPI()

class EnergyData(BaseModel):
    device_id: int
    timestamp: str
    consumption: float

class DeviceInfo(BaseModel):
    device_name: str
    device_type: str

class EnergyBudget(BaseModel):
  budget: float

@app.get("/energy", response_model=list[EnergyData])
async def get_energy_data():
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM energy_consumption")
    rows = cursor.fetchall()
    conn.close()
    return [{"device_id": row[1], "timestamp": row[2], "consumption": row[3]} for row in rows]

@app.get("/devices", response_model=list[DeviceInfo])
async def get_devices():
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM device_info")
    rows = cursor.fetchall()
    conn.close()
    return [{"device_name": row[1], "device_type": row[2]} for row in rows]

@app.post("/energy", response_model=EnergyData)
async def create_energy_data(energy_data: EnergyData):
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO energy_consumption (device_id, timestamp, consumption) VALUES (?, ?, ?)",
                   (energy_data.device_id, energy_data.timestamp, energy_data.consumption))
    conn.commit()
    conn.close()
    return energy_data

@app.post("/devices", response_model=DeviceInfo)
async def create_device(device_info: DeviceInfo):
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO device_info (device_name, device_type) VALUES (?, ?)",
                   (device_info.device_name, device_info.device_type))
    conn.commit()
    conn.close()
    return device_info


