# backend/database.py
import sqlite3

def create_connection():
    conn = None
    try:
        conn = sqlite3.connect('energy_data.db')
        return conn
    except sqlite3.Error as e:
        print(e)
    return conn

def create_tables():
    conn = create_connection()
    if conn is not None:
        try:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS energy_consumption (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_id INTEGER,
                    timestamp TEXT,
                    consumption REAL
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS device_info (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_name TEXT,
                    device_type TEXT
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS energy_budget (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    budget REAL
                )
            """)
            conn.commit()
        except sqlite3.Error as e:
            print(e)
        finally:
            conn.close()

if __name__ == '__main__':
    create_tables()
